from django.shortcuts import render, redirect
from .models import Word, Item
import random
# Create your views here.
def home(request):
    if request.method == 'POST':
        
        new_word = Word.objects.create(
            word = request.POST['word']
        )
        return redirect('home')
    words = Word.objects.all()

    return render(request, 'home.html', {'words':words})

# mix부분인데, 일단 워드에 들어가있는게 3개이상이면, 랜덤으로 3개 뽑아서 mixed_word에 넣어줘야하고,
# 그걸 아이템으로 매칭해야하는데 N:N 형태가 아니라 1:N 두개를 이어붙이는 형태로 해야 순서가 안꼬일 것 같기도하고?
def mix(request):
    if request.method == 'POST':
        words = Word.objects.all()
        mixed_list = []
        for word in words:
            mixed_list.append(word)
        print(mixed_list, "mixed_list")
        mixed_words = Item.objects.all()
        mixed_word = random.sample(mixed_list, 3)
        print(mixed_word, "mixed_word")
        if len(words) >= 3 and mixed_words:
            for item in mixed_words:
                test_list = [ item.word1, item.word2, item.word3]
                print(test_list, "test_list")
                test_count = 0
                print("\n\n\n")
                for test_word in test_list:
                    if test_word in mixed_word:
                        test_count += 1
                        print(test_count, "test_count\n")
                        print(test_word, "test_word\n")
                        print(mixed_word, "mixed_word\n")
                if test_count !=3:
                    new_mixed_word = Item.objects.create(
                        title = mixed_word,
                        word1 = mixed_word[0],
                        word2 = mixed_word[1],
                        word3 = mixed_word[2],
                    )
                    mixed_after_words = Item.objects.all()
                    mixed_list = []
                    return render(request, 'mix.html', {'mixed_after_words':mixed_after_words})
                else:
                    mixed_after_words = Item.objects.all()
                    return render(request, 'mix.html',{'mixed_after_words':mixed_after_words, "error":"에러"})
            return render(request, 'mix.html', {'mixed_list':mixed_list})
        if(len(mixed_words) == 0):
            new_mixed_word = Item.objects.create(
                title = mixed_word,
                word1 = mixed_word[0],
                word2 = mixed_word[1],
                word3 = mixed_word[2],
            )
            mixed_after_words = Item.objects.all()
            return render(request, 'mix.html', {'mixed_after_words':mixed_after_words})
        else:
            return render(request, 'mix.html', {'mixed_list':mixed_list})
        
 
        # if len(words) >= 3:
        #     mixed_word = random.sample(mixed_list, 3)
        #     mixed_words = Item.objects.all()
        #     #중복 체크해야하는데 어떻게 하지..?
            
        #     print("\n\n\n")
        #     for item in mixed_words:
        #         test_list = [ item.word1.word, item.word2.word, item.word3.word]
        #         print(test_list)
        #         test_count = 0
        #         print("\n\n\n")
        #         for test_word in test_list:
        #             if test_word in mixed_word:
        #                 test_count += 1
        #                 print(test_count)
        #         if test_count !=3:
        #             new_mixed_word = Item.objects.create(
        #                 title = mixed_word,
        #                 word1 = mixed_word[0],
        #                 word2 = mixed_word[1],
        #                 word3 = mixed_word[2],
        #             )
        #             mixed_list = []
        #             return render(request, 'mix.html', {'mixed_words':mixed_words})
        #         else:
        #             return render(request, 'mix.html', 'mix.html',{"error":'에러'})
        # else:
        #     return redirect(request, 'mix.html')

    else:
        mixed_words = Item.objects.all()
        return render(request, 'mix.html', {'mixed_words':mixed_words})

def err(request):
    return render(request, 'err.html')

