from django.contrib import admin
from .models import Word, Item
# Register your models here.

admin.site.register(Word)
admin.site.register(Item)